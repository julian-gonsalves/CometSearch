# Where are the samples?

The DoubleClick Ad Exchange Buyer REST API samples are now hosted separately
from the client library project. You can find them
[here](https://github.com/googleads/googleads-adxbuyer-examples/tree/master/python).
