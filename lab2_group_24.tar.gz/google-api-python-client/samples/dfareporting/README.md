# Where are the samples?

The DoubleClick for Advertisers Reporting API samples are now hosted separately
from the client library project. You can find them
[here](https://github.com/googleads/googleads-dfa-reporting-samples).
