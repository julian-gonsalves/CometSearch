# Where are the samples?

The Google Cloud Storage API samples are now hosted separately
from the client library project. You can find them
[here](https://github.com/GoogleCloudPlatform/storage-file-transfer-json-python).

