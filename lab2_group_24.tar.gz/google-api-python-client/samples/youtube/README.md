# Where are the samples?

The YouTube API samples are now hosted separately
from the client library project. You can find them
[here](https://github.com/youtube/api-samples).
